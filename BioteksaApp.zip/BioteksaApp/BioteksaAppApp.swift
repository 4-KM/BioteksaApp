//
//  BioteksaAppApp.swift
//  BioteksaApp
//
//  Created by Eduardo Gersai Garcia Ventura on 18/09/23.
//

import SwiftUI

@main
struct BioteksaAppApp: App {
    var body: some Scene {
        WindowGroup {
            LoginBioteksa()
        }
    }
}
