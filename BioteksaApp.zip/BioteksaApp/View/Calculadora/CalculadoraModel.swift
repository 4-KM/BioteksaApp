//
//  CalculadoraModel.swift
//  BioteksaApp
//
//  Created by Eduardo Gersai Garcia Ventura on 23/09/23.
//

import Foundation


struct Necesario {
    let molecula: String
}

// CHECAR SI TIENE ERROR DE CONTINUIDAD CON LOS ELEMENTOS

let necesario =  [
    
    Necesario(molecula: "NO3"),
    Necesario(molecula: "H2PO4"),
    Necesario(molecula: "K+"),
    Necesario(molecula: "CA+2"),
    Necesario(molecula: "MG+2"),
    Necesario(molecula: "SO4-2")
    
]
