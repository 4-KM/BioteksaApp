//
//  VolumenDeriegoModel.swift
//  BioteksaApp
//
//  Created by Eduardo Gersai Garcia Ventura on 22/09/23.
//

import Foundation


struct VolumenDeRiegoModel {
    let nombre: String
}

// CHECAR SI TIENE ERROR DE CONTINUIDAD CON LOS ELEMENTOS

let productos =  [
    
    VolumenDeRiegoModel(nombre: "HBK Plus"),
    VolumenDeRiegoModel(nombre: "ULTRA N"),
    VolumenDeRiegoModel(nombre: "ULTRA P"),
    VolumenDeRiegoModel(nombre: "ULTRA K"),
    VolumenDeRiegoModel(nombre: "ULTRA CA"),
    VolumenDeRiegoModel(nombre: "ULTRA MG"),
    VolumenDeRiegoModel(nombre: "HYPER MN")
    
]
