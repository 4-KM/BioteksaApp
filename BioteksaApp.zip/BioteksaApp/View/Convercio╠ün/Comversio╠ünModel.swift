//
//  ComversiónModel.swift
//  BioteksaApp
//
//  Created by Eduardo Gersai Garcia Ventura on 23/09/23.
//

import Foundation



struct Elementos {
    let nombre: String
}


let elementos =  [
    
    Elementos(nombre: "NITROGENO"),
    Elementos(nombre: "FOSFORO "),
    Elementos(nombre: "POTASIO"),
    Elementos(nombre: "CALCIO"),
    Elementos(nombre: "MAGNECIO"),
    Elementos(nombre: "AZUFRE"),
    
]
