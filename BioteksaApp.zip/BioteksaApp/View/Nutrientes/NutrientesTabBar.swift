//
//  NutrientesTabBar.swift
//  BioteksaApp
//
//  Created by Eduardo Gersai Garcia Ventura on 18/09/23.
//

import SwiftUI

struct NutrientesTabBar: View {
    var body: some View {
        ZStack {
            Color(red: 0.681, green: 0.695, blue: 1.000)
            //.edgesIgnoringSafeArea(.all)
        }  
    }
}

struct NutrientesTabBar_Previews: PreviewProvider {
    static var previews: some View {
        NutrientesTabBar()
    }
}
